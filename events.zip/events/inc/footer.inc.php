<div class="container-fluid" style="padding: 0px 0px;min-height: 150px;background-color:#4E4E4E;margin-top:50px;">
<div>
&nbsp;
</div>
<div>
&nbsp;
</div>

<div class="col-sm-4 text-center">

<ul style="list-style-type: none;padding-left:0px;">
<h3 style="color:#908F8F;font-size:1.5em;font-weight:700;">About</h3>
<li><a href="#" class="blink" style="text-decoration:none;pointer-events:none;">About Us</a></li>
</ul>
</div>
<div class="col-sm-4 text-center">

<ul style="list-style-type: none;padding-left:0px;">
<h3 style="color:#908F8F;font-size:1.5em;font-weight:700;">Suggest Us</h3>
<li><a href="suggestions.php" class="blink" style="text-decoration:none;">Suggestions</a></li>
</ul>
</div>
<div class="col-sm-4 text-center">
<ul style="list-style-type: none;padding-left:0px;">
<h3 style="color:#908F8F;font-size:1.5em;font-weight:700;">Connect</h3>
<li style="color:#fff;">admin@bvulive.in</li>

<li style="color:#fff;">09582505592</li>
</ul>
</div>


</div>






<!--Selectize JS File-->
<script src="js/searchnavbar.js" type="text/javascript"></script>

<?php include_once("./analyticstracking.php"); ?>
</body>
</html>