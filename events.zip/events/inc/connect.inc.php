<?php

mysql_connect("localhost" , "bvulimdk_niks" , "myniki123") or die("Couldn't connect to SQL");
mysql_select_db("bvulimdk_bvuevents") or die("Couldn't select DB");

?>