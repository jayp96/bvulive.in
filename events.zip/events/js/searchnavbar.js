$(document).ready(function(){

    $ne_res = $('#ne_name').selectize({
        openOnFocus: false,
        closeAfterSelect : true,
        scrollDuration : 300,
        persist: false
    });
    $event = $ne_res[0].selectize;
  

});